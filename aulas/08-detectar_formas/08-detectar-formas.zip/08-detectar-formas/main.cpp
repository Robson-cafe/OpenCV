#include "formas.hpp"

int main( int argc, char ** argv ){
  Formas formas;
  formas.desenhar_nas_formas();
  return 0;
}
